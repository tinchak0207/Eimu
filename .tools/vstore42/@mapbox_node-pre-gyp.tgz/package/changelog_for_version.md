- Test the release workflow

