# @vercel/build-utils

## 14.2.0

### Minor Changes

- e340c58: Add schedules/v1beta to TriggerEvent types

## 14.1.1

### Patch Changes

- b4f09c1: Support selecting Bun 1.4.x as an explicit runtime and build-time package manager, including local Bun servers.

## 14.1.0

### Minor Changes

- 852e1a0: Move middleware matcher utils from node builder to general build utils.

## 14.0.5

### Patch Changes

- 2da7809: Remove redundant and ineffective package tests.
- Updated dependencies [2da7809]
  - @vercel/python-analysis@0.13.2

## 14.0.4

### Patch Changes

- 13f81ac: Support pnpm lockfiles containing multiple YAML documents.

## 14.0.3

### Patch Changes

- d72826e: Prevented unit tests and generated outputs from changing Turborepo task inputs during CI, and removed the redundant affected Unit test retry.

## 14.0.2

### Patch Changes

- b7ec19b: Scope the pre-compilation install's `VERCEL_INSTALL_COMPLETED` marker to the `package.json` it installed. Previously, a `vercel.toml`/`vercel.ts` config caused `vc build` to install at the repo root and then silently skip every later default install, so services whose install root is a different workspace (its own `package.json`/lockfile) built without dependencies.

## 14.0.1

### Patch Changes

- 6d7fbfa: Bump all workspace packages to trigger a full publish from vercel-internal.
- Updated dependencies [6d7fbfa]
  - @vercel/python-analysis@0.13.1

## 14.0.0

### Major Changes

- 5c33351: Remove `getOsRelease()`, and stop deriving the provided runtime from the build host.

  `getProvidedRuntime()` is retained and now always resolves to `'provided.al2023'`. It previously read `/etc/os-release` and returned `'provided.al2'` on Amazon Linux 2 hosts, so the emitted runtime depended on where the build ran — a `vercel build` on an AL2 machine produced output that is rejected at deploy time, because `provided.al2` is no longer an accepted Lambda runtime. Custom runtimes calling `getProvidedRuntime()` need no changes and are fixed by this release.

  `getOsRelease()` is removed with no replacement.

  `validateBuildResult()` no longer accepts an `osRelease` option. Its runtime allowlist check was previously skipped unless the caller passed `osRelease.VERSION === '2023'`; it now always runs.

### Minor Changes

- b747ab4: Replace the inferred PPR fields on `Prerender` with the Next.js prerender taxonomy.

  `hasPostponed`, `hasFallback`, `isDynamicRoute` and `htmlSize` were derived by
  `@vercel/next` from build artifacts (the `.meta` postponed state, which manifest
  section a route came from, and a `statSync` of the `.html` shell). Next.js
  `>= 16.3.0-canary.96` publishes its own classification in the prerender
  manifest, so those four fields are removed in favour of a single optional
  `prerenderClassification` on `Prerender` / `PrerenderOptions`:

  - `routeType` — `'route' | 'page' | 'shell' | 'fallback'`
  - `response` — `'empty' | 'initial' | 'complete'`
  - `compute` — `'blocking' | 'resuming' | 'static'`
  - `htmlSize` — byte size of the prerendered HTML shell, when the entry has one

  The values are carried through unvalidated so a taxonomy value added by a future
  Next.js release cannot hard-fail a deploy. `@vercel/next` sets the field only
  when Next.js supplied the complete group — absence is legitimate for
  `notFoundRoutes` and Pages Router `fallback: false` templates — and only on the
  primary output of each prerender group, so a route is classified exactly once.

- 5619873: Fix api dir builds receiving incorrect framework or runtime.

### Patch Changes

- Updated dependencies [08a2618]
  - @vercel/python-analysis@0.13.0

## 13.36.3

### Patch Changes

- a69c714: Propagate per-function `maxConcurrency` configuration into build outputs and keep every configured Next.js route in its own Lambda group, including routes with the same limit.
- 654e898: Type shared function settings in container image build outputs.

## 13.36.2

### Patch Changes

- 2c75803: Preserve 4-byte UTF-8 characters when streaming string `FileBlob` contents (fixes Edge Function corruption during `vercel build`).

## 13.36.1

### Patch Changes

- 17ee736: Replace the vercel-workers integration for Python queue subscribers and workflows with the new vercel-queue SDK:

  - `[[tool.vercel.subscribers]]` entrypoints are introspected at build time via `vercel.queue.get_subscriptions()` and served through generated `vercel.queue.asgi_app()` handler modules, with `queue/v2beta` triggers carrying the SDK-registered consumer groups and per-subscription tuning.
  - Celery and Dramatiq projects get the matching `vercel-celery`/`vercel-dramatiq` integration package injected automatically (bundled variant unless `vercel-queue` is an explicit dependency), in builds and in `vercel dev`.
  - `[[tool.vercel.workflows]]` entrypoints follow the SDK generation: projects on `vercel` >= 0.8.0 are served through vercel-queue like subscribers; older or undeterminable versions keep the legacy vercel-workers serving (worker env markers, injected pinned `vercel-workers`).
  - Projects that depend on `vercel-workers` directly keep the legacy integration wholesale: legacy subscriber schema, direct entrypoint serving, worker env markers.
  - `vercel dev` serves queue sidecars through `vercel.queue.asgi_app()` for new-SDK projects, and its queue broker delivers with the SDK-registered consumer groups introspected at sidecar startup (matching production trigger behavior); legacy projects keep the vercel-workers bootstrap.
  - The CLI no longer injects `config.hasWorkerServices`; the Python builder makes all queue-serving decisions from project metadata.

## 13.36.0

### Minor Changes

- 4502520: Support Node.js Routing Middleware entrypoints through `proxy.entrypoint`, with optional path matching through `proxy.matcher`. The matcher may be configured in the entrypoint source or `vercel.json`, but not both.

### Patch Changes

- Updated dependencies [6aa29e5]
  - @vercel/python-analysis@0.12.0

## 13.35.0

### Minor Changes

- 7dd4301: Make service bindings type optional.

## 13.34.0

### Minor Changes

- 238543c: Support Python services that declare their web app and development workflow sidecars through a `pyproject.toml` entrypoint in `vercel dev`.

## 13.33.1

### Patch Changes

- def07fc: Migrate `@vercel/client` and `@vercel/build-utils` from `node-fetch` to native `fetch`. This removes the last `url.parse()` usage from the CLI bundle, which triggered a `DEP0169` DeprecationWarning on Node 24 (visible in the standalone binary during `vercel deploy`).

  BREAKING CHANGE (`@vercel/client`): the `agent?: http.Agent` option was replaced with `dispatcher?: FetchDispatcher` (an undici dispatcher, e.g. `undici.ProxyAgent`), since native `fetch` does not support Node.js HTTP agents. The CLI now threads its proxy-aware dispatcher through automatically, so `HTTP_PROXY`/`HTTPS_PROXY` behavior is unchanged for CLI users.

## 13.33.0

### Minor Changes

- 607f0ef: Add service information to deploy-manifest.

## 13.32.3

### Patch Changes

- 7b30856: Add `vercel dev` support for Python queue subscribers defined in `pyproject.toml`.

## 13.32.2

### Patch Changes

- 6b49a17: Apply per-service `functions` config when building experimental V2 services. Previously, function configuration declared under `services.<name>.functions` in `vercel.json` (`experimentalTriggers`, `maxDuration`, `memory`, `architecture`, `regions`, `functionFailoverRegions`, `supportsCancellation`) was dropped at build time — only the top-level `functions` map was honored. The build now feeds each service's `functions` to its lambdas for both single-lambda builders (`@vercel/node`, etc., via `writeBuildResultV3`) and framework builders that read `config.functions` (e.g. `@vercel/next`, via the builder config). Derived `queue/v2beta` consumer groups are now scoped by the owning service name so two services that declare the same function path + topic no longer collide.

## 13.32.1

### Patch Changes

- 8dc4702: Fix `vercel dev` for standalone Node servers, including projects without a `package.json`, and reuse the server process between requests.

## 13.32.0

### Minor Changes

- 9fb2976: Add `services` as the canonical multi-service project configuration and keep `experimentalServicesV2` as a deprecated backwards-compatible alias.

### Patch Changes

- 186014d: Add an experimental container service runtime. A service with
  `runtime: "container"` either builds its `Dockerfile`/`Containerfile` and pushes
  the resulting OCI image to the Vercel Container Registry (VCR), or passes a
  prebuilt image reference through as build output.

  - **`@vercel/container`** (new builder): authenticates to VCR with the project's
    `VERCEL_OIDC_TOKEN`, ensures the repository exists, builds and pushes the
    image, and emits a digest-pinned reference in `handler` (container functions
    are `type: "Lambda"` with `runtime: "container"`; the platform surfaces
    `handler` as the image downstream). Uses `docker` on developer machines and
    `buildah` (daemonless) in the Vercel build container behind a shared
    `ContainerEngine` interface. Supports `vc dev` via `startDevServer` (local
    build/run, env parity, log forwarding) and `prepareCache` for buildah layer
    reuse between builds. Build flow is instrumented with tracing spans
    (non-secret diagnostics) and debug logging gated on `BUILDER_DEBUG`.
  - **`@vercel/build-utils`**: add the `ContainerImage` build-output type.
  - **`@vercel/fs-detectors`**: resolve container services from `vercel.json`
    (the `services` config and its deprecated `experimentalServices` /
    `experimentalServicesV2` aliases). A `Dockerfile`, `Containerfile`, or
    `*.dockerfile` entrypoint triggers a build; any other entrypoint is treated as
    a prebuilt OCI image reference.
  - **`vercel`**: wire container output into `vercel build` result writing and
    config validation.

  Buildah specifics in the build container: host networking for `RUN` steps,
  native `overlay` storage on the XFS `/vercel` volume (deferring to the image's
  `storage.conf`), zstd push compression, and registry credentials read from the
  provisioned auth file when present. Several knobs are available for debugging:
  `VERCEL_CONTAINER_ENGINE`, `VERCEL_VCR_STRICT_STORAGE`,
  `VERCEL_VCR_DISABLE_LAYER_CACHE`, and `VERCEL_VCR_FORCE_LOGIN`.

- cb0988f: Set the Node.js 20 discontinuation date to October 1, 2026.

## 13.31.1

### Patch Changes

- 2158ab6: [vc dev] Add support to `experimentalServicesV2` for bindings in `vc dev`

## 13.31.0

### Minor Changes

- 8dec9ea: Add deploy-manifest as an extension of project manifest.
- 3afdb18: Emit project manifest for hugo, zola, jekyll, and middleman frameworks.
- 04f830c: Autodetect Bun runtime if engines.bun is set.

## 13.30.0

### Minor Changes

- 01e18e8: Add `hasFallback`, `htmlSize`, and `isDynamicRoute` to `Prerender`

  These optional fields surface per-route PPR shell metadata in the Build Output so consumers can classify prerenders (e.g. full shell vs. empty shell vs. concrete prerender):

  - `hasFallback` — whether a dynamic route template had a static fallback (`undefined` for concrete prerenders)
  - `htmlSize` — byte size of the prerendered `.html` shell (`0` for an empty shell, `undefined` when there's no `.html`)
  - `isDynamicRoute` — whether the entry came from a dynamic route template rather than a concrete prerender

## 13.29.1

### Patch Changes

- 32a730e: Elevate maximum maxDuration to 1800s

## 13.29.0

### Minor Changes

- 8d8e871: Evaluate the `maxDuration` upper bound at validation time so `VERCEL_CLI_SKIP_MAX_DURATION_LIMIT` works regardless of import order.

  The gate was read when `@vercel/build-utils`' `functionsSchema` was constructed and when the CLI compiled its `vercel.json` validator — both at module load. Any process that imports these modules before setting the env var baked in the default 900-second maximum and ignored the flag, failing with `Invalid vercel.json - functions[...].maxDuration should be <= 900`.

  `@vercel/build-utils` now exposes `getFunctionsSchema()`, which reads the limit at call time (the existing `functionsSchema` const is kept but deprecated). The CLI builds and compiles its config validator lazily, caching one validator per resolved limit, so setting the variable after import takes effect. Default behavior is unchanged — the 900s maximum, the lower bound, and the integer check are all still enforced when the variable is unset.

## 13.28.0

### Minor Changes

- 4e849dd: Add a per-route `hasPostponed` signal to `Prerender`.

  `@vercel/build-utils` exposes a new optional `hasPostponed?: boolean` field on `Prerender` / `PrerenderOptions`. It is a tri-state: `true` when the route's `.meta` postponed state is present (React suspended during the build-time prerender), `false` when the framework prerendered a Prerender route without postponing, and `undefined` when the framework did not provide the signal.

  `@vercel/next` populates it for app-router PPR routes (computed from the route's postponed state) and leaves it `undefined` for pages-router and other non-app-router prerenders. This is an additive, finer-grained signal — it does not change the existing `chain` / `experimentalStreamingLambdaPath` behavior — so downstream consumers can distinguish a route that actually postponed from one that has PPR machinery but fully prerendered (e.g. under `cacheComponents: true`).

## 13.27.2

### Patch Changes

- c5eeb30: Gate the client-side 900-second `maxDuration` upper bound behind the `VERCEL_CLI_SKIP_MAX_DURATION_LIMIT` environment variable. The limit is now owned by a single helper in `@vercel/build-utils` instead of being hardcoded in multiple validators. When the variable is set to `1`, the client-side maximum is skipped and validation defers to the server. Default behavior is unchanged — the maximum, the lower bound, and the integer check are all still enforced when the variable is unset.
- 09c39af: Fix Node.js API entrypoint detection dropping functions whose source contains comment-like sequences (`/*`, `//`, `*/`) inside string, template, or regex literals — for example an `Accept: */*` header. Handler exports are now identified with the ES/CJS module lexers instead of stripping comments with regexes, so the contents of literals are never mistaken for comments.

## 13.27.1

### Patch Changes

- 0a170fd: [services] wire `experimentalServicesV2` into `fs-detectors`.

## 13.27.0

### Minor Changes

- 338cc35: Add isPackageInstalled util for detecting dependencies during build.
  Fix Vercel Flags dependency detection for emitting datafiles during builds with OIDC tokens.

## 13.26.6

### Patch Changes

- 3019788: [services] Remove the `services` field from `vercel.json` and the `VERCEL_USE_SERVICES` gate.
- fe893ec: [services] Add `experimentalServicesV2` field to `vercel.json` implementing the new schema for services.

## 13.26.5

### Patch Changes

- 1180675: Revert "[flags] fix dep detection for build embedding (#16242)"

## 13.26.4

### Patch Changes

- 6495585: [services] drop top-level `env` support for the new `service-ref` shape for services.

## 13.26.3

### Patch Changes

- b66bd3e: Fix prebuilt deployments failing with "invalid relative path" when using the `--standalone` flag in pnpm monorepos by skipping external node_modules symlinks and copying traced files at their logical paths instead.

## 13.26.2

### Patch Changes

- 647c1e8: Cleanup getLambdaSupportsStreaming

## 13.26.1

### Patch Changes

- fa25cb7: Fix config.framework in deserializeBuildOutput
- 972cc84: Support workflow-triggered job services in queue infrastructure

  Add `isWorkflowTriggeredService()` and `isQueueBackedService()` helpers so workflow services
  are recognized by the queue broker, dev server, and build pipeline. Update Python runtime to
  bootstrap workflow services as queue-backed workers.

## 13.26.0

### Minor Changes

- 137e5d1: Allow builder V2 to expose startDevServer.

### Patch Changes

- bb61428: Include framework slug in output/config.json

## 13.25.0

### Minor Changes

- fb0cb8d: Add normalized entrypoint detector for runtime builders.
- 4fc110b: [services] add preDeployCommand for experimentalServices

## 13.24.0

### Minor Changes

- d874af6: Add support for env vars injection that reference other services in `services` with an explicit `env` configuration.

## 13.23.0

### Minor Changes

- 22f77b9: Add project manifest to node builder.

### Patch Changes

- 979d70a: [services] `services` schema support

## 13.22.1

### Patch Changes

- f0d7d32: Disable response streaming for lambdas with `awsLambdaHandler` set inside `getLambdaSupportsStreaming`. This closes a gap where non-Node builders (e.g. `@vercel/redwood`) constructed `NodejsLambda` with `awsLambdaHandler` but no explicit `supportsResponseStreaming`, causing `finalizeLambda` to silently flip streaming on for AWS custom handlers. With the gate now enforced centrally in `finalizeLambda`, the equivalent `@vercel/node` build-time check from #16266 is consolidated away — all builders go through the same gate.

## 13.22.0

### Minor Changes

- e53dd86: Add service type to project manifest.

## 13.21.0

### Minor Changes

- c56f851: Upgrade to TypeScript 5.9

### Patch Changes

- Updated dependencies [8e999cb]
  - @vercel/python-analysis@0.11.1

## 13.20.0

### Minor Changes

- Add framework to package manifest for python and backends builders. ([#16072](https://github.com/vercel/vercel/pull/16072))

### Patch Changes

- Add shared build output deserialization helpers for existing callers. ([#16072](https://github.com/vercel/vercel/pull/16072))

## 13.19.1

### Patch Changes

- [build-utils] simplify streaming lambda check ([#15795](https://github.com/vercel/vercel/pull/15795))

## 13.19.0

### Minor Changes

- [services] move Python workers to v2beta triggers with private routing ([#15920](https://github.com/vercel/vercel/pull/15920))

### Patch Changes

- Added a shared build result validation helper in `@vercel/build-utils` for existing callers. ([#16030](https://github.com/vercel/vercel/pull/16030))

## 13.18.0

### Minor Changes

- Generate PROJECTMANIFEST in @vercel/backends for Node deployments. ([#15991](https://github.com/vercel/vercel/pull/15991))

## 13.17.2

### Patch Changes

- [experimental-services] add new job service type support ([#15944](https://github.com/vercel/vercel/pull/15944))

## 13.17.1

### Patch Changes

- Align deserialize logic with existing callers. ([#16002](https://github.com/vercel/vercel/pull/16002))

## 13.17.0

### Minor Changes

- Support dynamically specifying crons from a python service ([#15930](https://github.com/vercel/vercel/pull/15930))

## 13.16.0

### Minor Changes

- Add shared deserialization and build-result collection utilities. ([#15961](https://github.com/vercel/vercel/pull/15961))

- Add root to experimentalServices to set a service's working directory. ([#15929](https://github.com/vercel/vercel/pull/15929))

- Add a new flag to vercel deploy to let users deploy to hive ([#15892](https://github.com/vercel/vercel/pull/15892))

## 13.15.0

### Minor Changes

- [services] allow multiple v2beta triggers for a single Lambda when config is coming from services ([#15890](https://github.com/vercel/vercel/pull/15890))

### Patch Changes

- Add deserialization utilities ([#15927](https://github.com/vercel/vercel/pull/15927))

## 13.14.2

### Patch Changes

- Add `mount` support for experimental services across config validation and service resolution. ([#15882](https://github.com/vercel/vercel/pull/15882))

## 13.14.1

### Patch Changes

- Restore `finalizeLambda()` to return `zipPath: null` for the default in-memory path, preserving the existing caller-facing result contract while keeping custom ZIP strategies supported. ([#15887](https://github.com/vercel/vercel/pull/15887))

- feat(node): filter non-entrypoint Node.js files in `/api` directory ([#15873](https://github.com/vercel/vercel/pull/15873))

## 13.14.0

### Minor Changes

- Support configuration via vercel.toml ([#15750](https://github.com/vercel/vercel/pull/15750))

## 13.13.0

### Minor Changes

- Extend `finalizeLambda` with pluggable ZIP strategy (`createZip`), pre-digest validation hook (`validateZip`), and optional trace tags. Widen `getLambdaEnvironment` buffer param to `{ byteLength: number }`. ([#15856](https://github.com/vercel/vercel/pull/15856))

## 13.12.2

### Patch Changes

- Extract finalize/validate function utils for build-utils ([#15776](https://github.com/vercel/vercel/pull/15776))

## 13.12.1

### Patch Changes

- Switch to using smol-toml for toml parsing ([#15730](https://github.com/vercel/vercel/pull/15730))

## 13.12.0

### Minor Changes

- Add hash utilities (`streamToDigestAsync`, `sha256`, `md5`) and build result helpers (`getBuildResultMetadata`, `getLambdaByOutputPath`, `isRouteMiddleware`, `getPrerenderChain`, `streamWithExtendedPayload`) for shared use. ([#15726](https://github.com/vercel/vercel/pull/15726))

## 13.11.0

### Minor Changes

- Add `process-serverless` utilities: `getLambdaEnvironment`, `getLambdaPreloadScripts`, `getLambdaSupportsStreaming`, and `getEncryptedEnv`. ([#15712](https://github.com/vercel/vercel/pull/15712))

## 13.10.0

### Minor Changes

- [services] support multiple topics for a single worker service ([#15615](https://github.com/vercel/vercel/pull/15615))

- [services] support for specifying an env prefix for each service ([#15641](https://github.com/vercel/vercel/pull/15641))

- Simplify python runtime by always passing in app variable ([#15635](https://github.com/vercel/vercel/pull/15635))

### Patch Changes

- Namespace diagnostics keys by builder and service workspace, and aggregate per-builder `package-manifest.json` files into a single `project-manifest.json` ([#15399](https://github.com/vercel/vercel/pull/15399))

- Updated dependencies [[`ac87d5a5ef5d79b55765e094efc957de987d7ac4`](https://github.com/vercel/vercel/commit/ac87d5a5ef5d79b55765e094efc957de987d7ac4), [`25a6a2daa46baba6e8d7dec90eb49213b8150b8c`](https://github.com/vercel/vercel/commit/25a6a2daa46baba6e8d7dec90eb49213b8150b8c)]:
  - @vercel/python-analysis@0.11.0

## 13.9.0

### Minor Changes

- Ensure django static files are copied in build output. ([#15557](https://github.com/vercel/vercel/pull/15557))

## 13.8.2

### Patch Changes

- [services] allow services to share builder source ([#15631](https://github.com/vercel/vercel/pull/15631))

- Updated dependencies [[`8e8110d2eca5832e109f5efb64b192690100927d`](https://github.com/vercel/vercel/commit/8e8110d2eca5832e109f5efb64b192690100927d)]:
  - @vercel/python-analysis@0.10.1

## 13.8.1

### Patch Changes

- Updated dependencies [[`3c4355fa1414aa3270ba4d36423aa647d49a9cf3`](https://github.com/vercel/vercel/commit/3c4355fa1414aa3270ba4d36423aa647d49a9cf3), [`267223f86eb578cc740db501fb2c2cbf43a27b37`](https://github.com/vercel/vercel/commit/267223f86eb578cc740db501fb2c2cbf43a27b37), [`e9a791d0fa04ef58695535fa508554415137fb58`](https://github.com/vercel/vercel/commit/e9a791d0fa04ef58695535fa508554415137fb58), [`12811e7bc827900d534aa25f5f3e2331a80ca6a8`](https://github.com/vercel/vercel/commit/12811e7bc827900d534aa25f5f3e2331a80ca6a8)]:
  - @vercel/python-analysis@0.10.0

## 13.8.0

### Minor Changes

- Support `maxDuration: 'max'` to allow the backend to resolve the maximum duration based on account plan type ([#15217](https://github.com/vercel/vercel/pull/15217))

### Patch Changes

- Fix EEXIST error when using `--standalone` flag in monorepos by handling pre-existing symlinks in the shared output directory. ([#15322](https://github.com/vercel/vercel/pull/15322))

## 13.7.2

### Patch Changes

- Updated dependencies [[`a67131396956632b060895afe44b26bb99941817`](https://github.com/vercel/vercel/commit/a67131396956632b060895afe44b26bb99941817)]:
  - @vercel/python-analysis@0.9.1

## 13.7.1

### Patch Changes

- [services] adds support for subdomai configuration in experimentalServices ([#15401](https://github.com/vercel/vercel/pull/15401))

## 13.7.0

### Minor Changes

- [python] add support for module-based entrypoints for cron jobs ([#15393](https://github.com/vercel/vercel/pull/15393))

- For the django frontend, dynamically load settings.py instead of parsing it ([#15367](https://github.com/vercel/vercel/pull/15367))

### Patch Changes

- Updated dependencies [[`83e804013528fc54de31082960ae31f58339bd71`](https://github.com/vercel/vercel/commit/83e804013528fc54de31082960ae31f58339bd71), [`921314f958c4ec85adb09e020310a5becb7f866c`](https://github.com/vercel/vercel/commit/921314f958c4ec85adb09e020310a5becb7f866c)]:
  - @vercel/python-analysis@0.9.0

## 13.6.3

### Patch Changes

- Updated dependencies [[`d1c4d7052033aaf7b3f2044aa24484cb143b9348`](https://github.com/vercel/vercel/commit/d1c4d7052033aaf7b3f2044aa24484cb143b9348)]:
  - @vercel/python-analysis@0.8.2

## 13.6.2

### Patch Changes

- add partialFallback flag to prerender output ([#14703](https://github.com/vercel/vercel/pull/14703))

## 13.6.1

### Patch Changes

- Updated dependencies [[`3880e1028840aae6883211b79a1a30c7432580f3`](https://github.com/vercel/vercel/commit/3880e1028840aae6883211b79a1a30c7432580f3)]:
  - @vercel/python-analysis@0.8.1

## 13.6.0

### Minor Changes

- Find entrypoints for django projects. ([#15167](https://github.com/vercel/vercel/pull/15167))

### Patch Changes

- Rename fetch to nodeFetch in cases where it is an import from node-fetch ([#15234](https://github.com/vercel/vercel/pull/15234))

- [@vercel/build-utils] fix uncaught exception in streamToBuffer when stream exceeds max Buffer size ([#15276](https://github.com/vercel/vercel/pull/15276))

- Remove source and destination typo suggestions for routes schema ([#15014](https://github.com/vercel/vercel/pull/15014))

- Support function overrides in backends builder ([#15214](https://github.com/vercel/vercel/pull/15214))

- Updated dependencies [[`b3a96cc4f276ce8d16c695eabd499d3a17e73aa8`](https://github.com/vercel/vercel/commit/b3a96cc4f276ce8d16c695eabd499d3a17e73aa8)]:
  - @vercel/python-analysis@0.8.0

## 13.5.0

### Minor Changes

- Add django experimental framework. ([#15196](https://github.com/vercel/vercel/pull/15196))

### Patch Changes

- Updated dependencies [[`cb79f6f8080fddd3673a8911566085e0265b060b`](https://github.com/vercel/vercel/commit/cb79f6f8080fddd3673a8911566085e0265b060b)]:
  - @vercel/python-analysis@0.7.0

## 13.4.3

### Patch Changes

- [services] ([#15093](https://github.com/vercel/vercel/pull/15093))
  - consolidate `workspace` and `entrypoint` from `experimentalServices` `vercel.json` schema
  - make `framework` config in service optional -- infer framework from service workspace when not explicitly provided
- Updated dependencies [[`fc56fb91b4dafabe0f68f86efeabbaf98b2642bc`](https://github.com/vercel/vercel/commit/fc56fb91b4dafabe0f68f86efeabbaf98b2642bc)]:
  - @vercel/python-analysis@0.6.0

## 13.4.2

### Patch Changes

- Updated dependencies [[`88353afe588b95709af20ba2b82ba83d8a60f90c`](https://github.com/vercel/vercel/commit/88353afe588b95709af20ba2b82ba83d8a60f90c)]:
  - @vercel/python-analysis@0.5.0

## 13.4.1

### Patch Changes

- Add support for `functions[*].functionFailoverRegions` in `vercel.json` and build output config generation. ([#14969](https://github.com/vercel/vercel/pull/14969))

  This enables per-function failover region configuration instead of only top-level defaults for all functions.

## 13.4.0

### Minor Changes

- [services] synchronize dependencies in dev mode for JS/TS and Python services ([#14987](https://github.com/vercel/vercel/pull/14987))

- [services] inject service URLs into web services as local paths ([#15024](https://github.com/vercel/vercel/pull/15024))

### Patch Changes

- Add new expirementalTrigger format for queues v2beta ([#14970](https://github.com/vercel/vercel/pull/14970))

- Updated dependencies [[`a960cf23a42ff1a570c808ee9567670c24422f98`](https://github.com/vercel/vercel/commit/a960cf23a42ff1a570c808ee9567670c24422f98)]:
  - @vercel/python-analysis@0.4.1

## 13.3.5

### Patch Changes

- Add service configuration to BuildOptions ([#14918](https://github.com/vercel/vercel/pull/14918))

- Updated dependencies [[`9b8f974bbb64fb857b068428b0c2fdccee6ad83c`](https://github.com/vercel/vercel/commit/9b8f974bbb64fb857b068428b0c2fdccee6ad83c)]:
  - @vercel/python-analysis@0.4.0

## 13.3.4

### Patch Changes

- Add support for `regions` in `vercel.json` function-level configuration. ([#14963](https://github.com/vercel/vercel/pull/14963))

  Matching function `regions` are now parsed from `functions` config, written into lambda output config, and documented in config types so they override top-level deployment regions for that function.

- [services] set framework prefixed env var urls to relative path ([#14958](https://github.com/vercel/vercel/pull/14958))

## 13.3.3

### Patch Changes

- Updated dependencies [[`2d61173cd73860fedc23edc0552c86d0e21fccd3`](https://github.com/vercel/vercel/commit/2d61173cd73860fedc23edc0552c86d0e21fccd3)]:
  - @vercel/python-analysis@0.3.2

## 13.3.2

### Patch Changes

- Improve memory efficiency in `FileBlob.fromStream()` by avoiding unnecessary buffer copies when chunks are already Buffers ([#14701](https://github.com/vercel/vercel/pull/14701))

- [services] build time service url env vars ([#14893](https://github.com/vercel/vercel/pull/14893))

- Updated dependencies [[`7a747344dfb778a650da2ee5f7fba8c974098b42`](https://github.com/vercel/vercel/commit/7a747344dfb778a650da2ee5f7fba8c974098b42)]:
  - @vercel/python-analysis@0.3.1

## 13.3.1

### Patch Changes

- Replace Python-based AST parser with WASM-based `@vercel/python-analysis` for detecting Python entrypoints. This eliminates the need for a Python runtime when analyzing Python files for WSGI/ASGI application patterns. ([#14843](https://github.com/vercel/vercel/pull/14843))

## 13.3.0

### Minor Changes

- Add multi-service support for `vercel dev`. When `VERCEL_USE_EXPERIMENTAL_SERVICES=1` is set, the CLI auto-detects different multi-service layouts and orchestrates dev servers for each service through a single proxy server. ([#14805](https://github.com/vercel/vercel/pull/14805))

### Patch Changes

- [services] add `services` to `config.json` ([#14847](https://github.com/vercel/vercel/pull/14847))

## 13.2.17

### Patch Changes

- Add `exposeErrBody` optional boolean property to Prerender object ([#14845](https://github.com/vercel/vercel/pull/14845))

- Move backends builder detection to detectBuilders phase ([#14830](https://github.com/vercel/vercel/pull/14830))

## 13.2.16

### Patch Changes

- Add maxConcurrency to experimentalTriggers ([#14725](https://github.com/vercel/vercel/pull/14725))

- Add maxConcurrency trigger field ([#14725](https://github.com/vercel/vercel/pull/14725))

## 13.2.15

### Patch Changes

- Optimize `getAvailableNodeVersions` to skip discontinued versions and use non-throwing `statSync` ([#14686](https://github.com/vercel/vercel/pull/14686))

## 13.2.14

### Patch Changes

- Add `experimentalServices` to `vercel.json` ([#14612](https://github.com/vercel/vercel/pull/14612))

## 13.2.13

### Patch Changes

- [python] experimental python runtime framework preset ([#14646](https://github.com/vercel/vercel/pull/14646))

## 13.2.12

### Patch Changes

- Add `findPackageJson` function for optimized package.json lookup without lockfile scanning. This improves `getNodeVersion` performance by avoiding unnecessary lockfile parsing. ([#14658](https://github.com/vercel/vercel/pull/14658))

## 13.2.10

### Patch Changes

- Add 'go' as a valid runtimeLanguage option for Lambda functions ([#14624](https://github.com/vercel/vercel/pull/14624))

## 13.2.9

### Patch Changes

- replace getRuntimeNodeVersion with getNodeVersion ([#14622](https://github.com/vercel/vercel/pull/14622))

## 13.2.8

### Patch Changes

- Remove getSpawnOptions ([#14604](https://github.com/vercel/vercel/pull/14604))

## 13.2.7

### Patch Changes

- Replace getNodeVersion with getRuntimeNodeVersion ([#14600](https://github.com/vercel/vercel/pull/14600))

- Add zero-config support for Koa.js ([#14567](https://github.com/vercel/vercel/pull/14567))

## 13.2.6

### Patch Changes

- Update http links in Node.js version incompatibility message to https ([#14583](https://github.com/vercel/vercel/pull/14583))

- Ensure internal build step runs if a build script is missing ([#14564](https://github.com/vercel/vercel/pull/14564))

## 13.2.5

### Patch Changes

- Adding in user configured deploymentId to build output type ([#14497](https://github.com/vercel/vercel/pull/14497))

- skip secondary installation for vercel.ts ([#14471](https://github.com/vercel/vercel/pull/14471))

## 13.2.4

### Patch Changes

- [python] only create api builders for `.py` files that export an app or handler ([#14493](https://github.com/vercel/vercel/pull/14493))

## 13.2.3

### Patch Changes

- Use `workspace:*` for workspace dependencies ([#14396](https://github.com/vercel/vercel/pull/14396))

## 13.2.2

### Patch Changes

- Bump NFT dependency ([#14373](https://github.com/vercel/vercel/pull/14373))

## 13.2.1

### Patch Changes

- Disables auto instrumentation when the app has manual instrumentation setup ([#14345](https://github.com/vercel/vercel/pull/14345))

## 13.2.0

### Minor Changes

- Remove env var check for node24 ([#14355](https://github.com/vercel/vercel/pull/14355))

## 13.1.2

### Patch Changes

- Support `runtimeLanguage` in build-utils ([#14344](https://github.com/vercel/vercel/pull/14344))

## 13.1.1

### Patch Changes

- Only run introspection when isExperimentalBackendsWithoutIntrospectionEnabled is truthy ([#14336](https://github.com/vercel/vercel/pull/14336))

## 13.1.0

### Minor Changes

- Remove --unsafe-perm from npm install command ([#14302](https://github.com/vercel/vercel/pull/14302))

## 13.0.2

### Patch Changes

- Improve warning messages surrounding Elysia ([#14272](https://github.com/vercel/vercel/pull/14272))

## 13.0.1

### Patch Changes

- Revert "Remove getSpawnOptions" ([#14261](https://github.com/vercel/vercel/pull/14261))

## 13.0.0

### Major Changes

- Remove getSpawnOptions ([#14176](https://github.com/vercel/vercel/pull/14176))

## 12.2.4

### Patch Changes

- Add helper for detecting backend builders ([#14182](https://github.com/vercel/vercel/pull/14182))

## 12.2.3

### Patch Changes

- Add Elysia framework ([#14164](https://github.com/vercel/vercel/pull/14164))

## 12.2.2

### Patch Changes

- Allow Node.js 24 behind env var feature flag ([#14160](https://github.com/vercel/vercel/pull/14160))

## 12.2.1

### Patch Changes

- Add backend util helpers ([#14152](https://github.com/vercel/vercel/pull/14152))

## 12.2.0

### Minor Changes

- Add support for Bun through a vercel.json property ([#14130](https://github.com/vercel/vercel/pull/14130))

## 12.1.3

### Patch Changes

- Revert the prebuilt archive split from 20MB back to 100MB ([#14103](https://github.com/vercel/vercel/pull/14103))

## 12.1.2

### Patch Changes

- Reuse duplicated node builder logic ([#14031](https://github.com/vercel/vercel/pull/14031))

## 12.1.1

### Patch Changes

- Change archive split from 100MB -> 20MB ([#14046](https://github.com/vercel/vercel/pull/14046))

## 12.1.0

### Minor Changes

- Support turbo.jsonc ([#13792](https://github.com/vercel/vercel/pull/13792))

## 12.0.0

### Major Changes

- Drop Node.js 18, bump minimum to Node.js 20 ([#13856](https://github.com/vercel/vercel/pull/13856))

## 11.0.2

### Patch Changes

- Add support for the supportsCancellation function flag ([#13807](https://github.com/vercel/vercel/pull/13807))

## 11.0.1

### Patch Changes

- Fix 404 status for /api routes when using Hono with the vercel dev server ([#13706](https://github.com/vercel/vercel/pull/13706))

## 11.0.0

### Major Changes

- Add support for vlt as a package manager ([#13591](https://github.com/vercel/vercel/pull/13591))

## 10.6.7

### Patch Changes

- Reverting support for `preferredRegion` ([#13566](https://github.com/vercel/vercel/pull/13566))

## 10.6.6

### Patch Changes

- Deprecate Node.js 18.x with warning ([#13549](https://github.com/vercel/vercel/pull/13549))

## 10.6.5

### Patch Changes

- rename experimental maxAttempts to maxDeliveries ([#13534](https://github.com/vercel/vercel/pull/13534))

## 10.6.4

### Patch Changes

- simplify experimental triggers ([#13527](https://github.com/vercel/vercel/pull/13527))

## 10.6.3

### Patch Changes

- make POST method required ([#13518](https://github.com/vercel/vercel/pull/13518))

- Update more handling for experimentalTriggers ([#13517](https://github.com/vercel/vercel/pull/13517))

## 10.6.2

### Patch Changes

- Add CloudEventTrigger support for Lambda functions ([#13503](https://github.com/vercel/vercel/pull/13503))

## 10.6.1

### Patch Changes

- next package uses @vercel/routing-utils HasField rather than redefining & stricter validation. ([#13409](https://github.com/vercel/vercel/pull/13409))

- Make architecture a defined property on Lambda classes to apply when creating ([#13398](https://github.com/vercel/vercel/pull/13398))

- [env-vars] expose VERCEL_PROJECT_ID as NEXT_PUBLIC_VERCEL_PROJECT_ID ([#13431](https://github.com/vercel/vercel/pull/13431))

## 10.6.0

### Minor Changes

- provide a more verbose error when package.json is not valid ([#13346](https://github.com/vercel/vercel/pull/13346))

- Allow configuring functions `architecture` via the `vercel.json` configuration ([#13344](https://github.com/vercel/vercel/pull/13344))

## 10.5.1

### Patch Changes

- Display warning when yarn dynamic require error may happen ([#13143](https://github.com/vercel/vercel/pull/13143))

- [build-utils] increase max memory limit ([#13162](https://github.com/vercel/vercel/pull/13162))

## 10.5.0

### Minor Changes

- Disable yarn global cache before installs so build cache caches deps ([#13144](https://github.com/vercel/vercel/pull/13144))

## 10.4.0

### Minor Changes

- Expose pnpm6 within the detected package manager path for future versions of the build container ([#13132](https://github.com/vercel/vercel/pull/13132))

## 10.3.2

### Patch Changes

- Add support for expire values in Next.js prerender manifest ([#13087](https://github.com/vercel/vercel/pull/13087))

- Detect yarn version from lockfile version ([#13118](https://github.com/vercel/vercel/pull/13118))

## 10.3.1

### Patch Changes

- Parse yarn.lock file version ([#13114](https://github.com/vercel/vercel/pull/13114))

- [env-vars] expose VERCEL_DEPLOYMENT_ID as NEXT_PUBLIC_VERCEL_DEPLOYMENT_ID ([#13115](https://github.com/vercel/vercel/pull/13115))

- Fix vitest-e2e glob to include integration.test.ts ([#13097](https://github.com/vercel/vercel/pull/13097))

## 10.3.0

### Minor Changes

- Delay pnpm@10 preferred date ([#13100](https://github.com/vercel/vercel/pull/13100))

### Patch Changes

- Type-check tests ([#13096](https://github.com/vercel/vercel/pull/13096))

## 10.2.0

### Minor Changes

- Detect v9 pnpm lock files as pnpm 10 for new projects ([#13072](https://github.com/vercel/vercel/pull/13072))

### Patch Changes

- Improve build log messages surrounding pnpm 10 ([#13088](https://github.com/vercel/vercel/pull/13088))

- [build-utils] extract checkIfAlreadyInstalled helper to clarify intent ([#13060](https://github.com/vercel/vercel/pull/13060))

- Allow pnpm 10 to use package.json#packageManager without an engines error ([#13083](https://github.com/vercel/vercel/pull/13083))

## 10.1.0

### Minor Changes

- [envs] add `VERCEL_TARGET_ENV` to prefixed env vars ([#13069](https://github.com/vercel/vercel/pull/13069))

## 10.0.1

### Patch Changes

- [build-utils] Move `runNpmInstallSema` closer to where it's used ([#13061](https://github.com/vercel/vercel/pull/13061))

- [build-utils] extract getInstallCommandForPackageManager to module scope ([#13058](https://github.com/vercel/vercel/pull/13058))

- [build-utils] remove redundant sema release ([#13059](https://github.com/vercel/vercel/pull/13059))

- Revert support pnpm 10 ([#13064](https://github.com/vercel/vercel/pull/13064))

## 10.0.0

### Major Changes

- Detect v9 pnpm lockfiles as pnpm 10 generated ([#12852](https://github.com/vercel/vercel/pull/12852))

## 9.3.1

### Patch Changes

- [build-utils] extract install command specific logic into helper ([#13049](https://github.com/vercel/vercel/pull/13049))

- [build-utils] remove dead node 16 check ([#13047](https://github.com/vercel/vercel/pull/13047))

## 9.3.0

### Minor Changes

- Support process tracing ([#12894](https://github.com/vercel/vercel/pull/12894))

## 9.2.1

### Patch Changes

- Add tracer utility to @vercel/build-utils ([#13013](https://github.com/vercel/vercel/pull/13013))

## 9.2.0

### Minor Changes

- Add .yarn/cache to build cache ([#12961](https://github.com/vercel/vercel/pull/12961))

## 9.1.1

### Patch Changes

- [cli] shift node 16 deprecation date to 2025-02-03 ([#12981](https://github.com/vercel/vercel/pull/12981))

## 9.1.0

### Minor Changes

- Add `useWebApi` property to `NodejsLambda` class ([#12873](https://github.com/vercel/vercel/pull/12873))

- [build-utils] convert NodeVersion to class and add state getter ([#12883](https://github.com/vercel/vercel/pull/12883))
  [ruby] convert RubyVersion to class and add state getter

## 9.0.1

### Patch Changes

- Revert build utils refactor ([#12818](https://github.com/vercel/vercel/pull/12818))

## 9.0.0

### Major Changes

- Change getPathOverrideForPackageManager() to use detectedLockfile argument ([#12813](https://github.com/vercel/vercel/pull/12813))

### Patch Changes

- Refactor build-util usage to reuse detected lockfile ([#12813](https://github.com/vercel/vercel/pull/12813))

- add support for `images.qualities` ([#12813](https://github.com/vercel/vercel/pull/12813))

## 8.8.0

### Minor Changes

- Add bun detection using bun.lock ([#12740](https://github.com/vercel/vercel/pull/12740))

## 8.7.0

### Minor Changes

- Support splitting archive deployments in parts. ([#12671](https://github.com/vercel/vercel/pull/12671))

## 8.6.0

### Minor Changes

- Add support for `NOW_EPHEMERAL_FILES_S3_URL`, `NOW_FILES_CLOUDFRONT_URL` and `NOW_FILES_S3_URL` environment variables ([#12643](https://github.com/vercel/vercel/pull/12643))

## 8.5.0

### Minor Changes

- Remove `VERCEL_ALLOW_NODEJS22` env var check ([#12614](https://github.com/vercel/vercel/pull/12614))

## 8.4.12

### Patch Changes

- Support allowHeader from Next.js for filtering request headers during revalidation ([#12420](https://github.com/vercel/vercel/pull/12420))

## 8.4.11

### Patch Changes

- Improve parsing of `turbo.json` ([#12266](https://github.com/vercel/vercel/pull/12266))

- Fix corepack `packageManager` detection on monorepos ([#12258](https://github.com/vercel/vercel/pull/12258))

## 8.4.10

### Patch Changes

- Parse `turbo.json` as json5 ([#12259](https://github.com/vercel/vercel/pull/12259))

## 8.4.9

### Patch Changes

- Fix special version specifier handling for `turbo` ([#12249](https://github.com/vercel/vercel/pull/12249))

## 8.4.8

### Patch Changes

- Revert "[build-utils] Fix corepack `packageManager` detection on monorepos" ([#12242](https://github.com/vercel/vercel/pull/12242))

## 8.4.7

### Patch Changes

- Disable corepack when Turborepo does not support `COREPACK_HOME` ([#12211](https://github.com/vercel/vercel/pull/12211))

- Fix corepack `packageManager` detection on monorepos ([#12219](https://github.com/vercel/vercel/pull/12219))

## 8.4.6

### Patch Changes

- add support for `images.localPatterns` ([#12195](https://github.com/vercel/vercel/pull/12195))

## 8.4.5

### Patch Changes

- [build-utils] add types for `images.remotePatterns.search` to vercel.json ([#12158](https://github.com/vercel/vercel/pull/12158))

## 8.4.4

### Patch Changes

- Allow Node.js v22 behind env var feature flag ([#12159](https://github.com/vercel/vercel/pull/12159))

## 8.4.3

### Patch Changes

- Introduce new chain configuration types for Partial Prerendering ([#12063](https://github.com/vercel/vercel/pull/12063))

## 8.4.2

### Patch Changes

- Revert "Revert "Revert "Fix corepack `packageManager` detection on monorepos""" ([#12099](https://github.com/vercel/vercel/pull/12099))

## 8.4.1

### Patch Changes

- Revert "Revert "Fix corepack `packageManager` detection on monorepos"" ([#11871](https://github.com/vercel/vercel/pull/11871))

## 8.4.0

### Minor Changes

- Change warnings to errors in invalid corepack package manager states ([#12062](https://github.com/vercel/vercel/pull/12062))

## 8.3.9

### Patch Changes

- Provide help when users get ERR_PNPM_UNSUPPORTED_ENGINE errors without corepack ([#12034](https://github.com/vercel/vercel/pull/12034))

- Fix package-manager-warning-1 to happen only happen in correct cases ([#12050](https://github.com/vercel/vercel/pull/12050))

## 8.3.8

### Patch Changes

- Limit `package.json#packageManager` parsing to concrete versions ([#12025](https://github.com/vercel/vercel/pull/12025))

- Catch PNPM_UNSUPPORTED_ENGINE when corepack is enabled and throw a more helpful error ([#12017](https://github.com/vercel/vercel/pull/12017))

## 8.3.7

### Patch Changes

- Revert "Revert "warn on mismatched corepack and detected package managers"" ([#11887](https://github.com/vercel/vercel/pull/11887))

## 8.3.6

### Patch Changes

- Remove implicit reliance on `@types/glob` for downstream consumers ([#11914](https://github.com/vercel/vercel/pull/11914))

## 8.3.5

### Patch Changes

- Revert "warn on mismatched corepack and detected package managers" ([#11879](https://github.com/vercel/vercel/pull/11879))

## 8.3.4

### Patch Changes

- Revert "Fix corepack `packageManager` detection on monorepos" ([#11865](https://github.com/vercel/vercel/pull/11865))

## 8.3.3

### Patch Changes

- Fix corepack `packageManager` detection on monorepos ([#11811](https://github.com/vercel/vercel/pull/11811))

## 8.3.2

### Patch Changes

- reject mismatched corepack and detected package managers ([#11603](https://github.com/vercel/vercel/pull/11603))

## 8.3.1

### Patch Changes

- Add build callback handling ([#11807](https://github.com/vercel/vercel/pull/11807))

## 8.3.0

### Minor Changes

- Adds the ability for builders to define a `diagnostics` step that is called after the build operation is done. ([#11653](https://github.com/vercel/vercel/pull/11653))
  Implements the diagnostics step in the `next` builder.

### Patch Changes

- Add resolved node version range to warning message ([#11742](https://github.com/vercel/vercel/pull/11742))

## 8.2.2

### Patch Changes

- Change node 16.x EOL for Vercel ([#11704](https://github.com/vercel/vercel/pull/11704))

- Improve error message and refactor ([#11706](https://github.com/vercel/vercel/pull/11706))

- [built-utils] Handle case of not having lockfile when corepack is enabled ([#11697](https://github.com/vercel/vercel/pull/11697))

## 8.2.1

### Patch Changes

- [node] update node@16 deprecation day ([#11671](https://github.com/vercel/vercel/pull/11671))

## 8.2.0

### Minor Changes

- fix corepack detection for package manager version determination ([#11596](https://github.com/vercel/vercel/pull/11596))

### Patch Changes

- Fix triggering of ignored project settings node version warning ([#11550](https://github.com/vercel/vercel/pull/11550))

## 8.1.3

### Patch Changes

- [build-utils] log more around package manager detection ([#11594](https://github.com/vercel/vercel/pull/11594))

## 8.1.2

### Patch Changes

- add log to package manager version detection ([#11592](https://github.com/vercel/vercel/pull/11592))

## 8.1.1

### Patch Changes

- [build-utils] pnpm lockfile testing and fixing ([#11591](https://github.com/vercel/vercel/pull/11591))

## 8.1.0

### Minor Changes

- Update pnpm version detection logic ([#11445](https://github.com/vercel/vercel/pull/11445))
  Add support for pnpm 9

## 8.0.0

### Major Changes

- Remove legacy `avoidTopLevelInstall` logic ([#11513](https://github.com/vercel/vercel/pull/11513))

### Patch Changes

- [build-utils] Add `VERCEL_PROJECT_PRODUCTION_URL` framework env var prefix ([#11506](https://github.com/vercel/vercel/pull/11506))

## 7.12.0

### Minor Changes

- Trigger release ([#11465](https://github.com/vercel/vercel/pull/11465))

## 7.11.0

### Minor Changes

- Add `getOsRelease()` and `getProvidedRuntime()` functions ([#11370](https://github.com/vercel/vercel/pull/11370))

## 7.10.0

### Minor Changes

- Allow environment variables to be specified for `EdgeFunction` ([#11029](https://github.com/vercel/vercel/pull/11029))

## 7.9.1

### Patch Changes

- Export `getSupportedNodeVersion` ([#11277](https://github.com/vercel/vercel/pull/11277))

## 7.9.0

### Minor Changes

- Add `base` parameter to `scanParentDirs()` ([#11261](https://github.com/vercel/vercel/pull/11261))

## 7.8.0

### Minor Changes

- Remove `VERCEL_ENABLE_NPM_DEFAULT` env var check ([#11242](https://github.com/vercel/vercel/pull/11242))

### Patch Changes

- Rename variants to flags and remove legacy flags ([#11121](https://github.com/vercel/vercel/pull/11121))

## 7.7.1

### Patch Changes

- [build-utils] increase max memory limit ([#11209](https://github.com/vercel/vercel/pull/11209))

## 7.7.0

### Minor Changes

- Revert "Revert "Default ruby to only currently supported version (3.2.0)"" ([#11137](https://github.com/vercel/vercel/pull/11137))

## 7.6.0

### Minor Changes

- Revert "Default ruby to only currently supported version (3.2.0)" ([#11135](https://github.com/vercel/vercel/pull/11135))

- Mark `flags` as deprecated and replace them with `variants` ([#11098](https://github.com/vercel/vercel/pull/11098))

- [build-utils] change default package manager when no lockfile detected from `yarn` to `npm` (gated behind feature flag) ([#11131](https://github.com/vercel/vercel/pull/11131))

### Patch Changes

- Update internal type for variants ([#11111](https://github.com/vercel/vercel/pull/11111))

## 7.5.1

### Patch Changes

- Add experimental field to Lambda and size to FileFsRef output ([#11059](https://github.com/vercel/vercel/pull/11059))

## 7.5.0

### Minor Changes

- Deprecate `EdgeFunction#name` property ([#11010](https://github.com/vercel/vercel/pull/11010))

## 7.4.1

### Patch Changes

- Extend Node v16 discontinue date to 2024-06-15 ([#10967](https://github.com/vercel/vercel/pull/10967))

## 7.4.0

### Minor Changes

- Adds new helper `getPathForPackageManager()` ([#10918](https://github.com/vercel/vercel/pull/10918))

## 7.3.0

### Minor Changes

- [cli] add `--deprecated` option to `vc project ls` command ([#10919](https://github.com/vercel/vercel/pull/10919))

## 7.2.5

### Patch Changes

- Remove Node.js v20 env var check ([#10834](https://github.com/vercel/vercel/pull/10834))

## 7.2.4

### Patch Changes

- Select Node.js version based on what's available in build-container ([#10822](https://github.com/vercel/vercel/pull/10822))

## 7.2.3

### Patch Changes

- Add experimental flag to allow Node.js v20 ([#10802](https://github.com/vercel/vercel/pull/10802))

## 7.2.2

### Patch Changes

- [cli] Update bun detection and add tests for projects with both bunlock binary and yarn.lock text files ([#10583](https://github.com/vercel/vercel/pull/10583))

## 7.2.1

### Patch Changes

- Internal variants ([#10549](https://github.com/vercel/vercel/pull/10549))

## 7.2.0

### Minor Changes

- Add new optional prerender field: experimentalStreamingLambdaPath ([#10476](https://github.com/vercel/vercel/pull/10476))

- [build-utils] Add zero config detection for bun package manager ([#10486](https://github.com/vercel/vercel/pull/10486))

### Patch Changes

- add `experimentalBypassFor` field to Prerender ([#10481](https://github.com/vercel/vercel/pull/10481))

## 7.1.1

### Patch Changes

- add descriptions to NodeVersion properties ([#10403](https://github.com/vercel/vercel/pull/10403))

- Updated semver dependency ([#10411](https://github.com/vercel/vercel/pull/10411))

## 7.1.0

### Minor Changes

- Support serverless function architecture ([#10392](https://github.com/vercel/vercel/pull/10392))

## 7.0.0

### Major Changes

- BREAKING CHANGE: Drop Node.js 14, bump minimum to Node.js 16 ([#10369](https://github.com/vercel/vercel/pull/10369))

## 6.8.3

### Patch Changes

- Fix `getPrefixedEnvVars()` to handle `VERCEL_BRANCH_URL` ([#10315](https://github.com/vercel/vercel/pull/10315))

## 6.8.2

### Patch Changes

- Push back `nodejs16.x` discontinue date to `2024-02-06` ([#10209](https://github.com/vercel/vercel/pull/10209))

## 6.8.1

### Patch Changes

- Revert "[build-utils] Allow file-ref sema to be controlled through env flag" ([#10167](https://github.com/vercel/vercel/pull/10167))

## 6.8.0

### Minor Changes

- Add `getNodeBinPaths()` and `traverseUpDirectories()` functions ([#10150](https://github.com/vercel/vercel/pull/10150))

## 6.7.5

### Patch Changes

- Publish missing build-utils ([`cd35071f6`](https://github.com/vercel/vercel/commit/cd35071f609d615d47bc04634c123b33768436cb))

## 6.7.4

### Patch Changes

- Remove usage of `env` from Edge Functions and Middleware ([#10018](https://github.com/vercel/vercel/pull/10018))

## 6.7.3

### Patch Changes

- Deprecate Node.js 14.x and 16.x with warning ([#9976](https://github.com/vercel/vercel/pull/9976))
